package stepDefinition;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepsFeature3 {

	WebDriver driver;

	@Before
	public void openBrowser() {
		System.setProperty("webdriver.gecko.driver", "D://tvvs-downloads//geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
	}

	// ---------------------------------------------------------

	@Given("^Open Sigarra page$")
	public void open_Sigarra_page() throws Throwable {
		driver.get("https://sigarra.up.pt");
		System.out.println("Sigarra page was opened");
	}

	@When("^Click on Search$")
	public void click_on_Search() throws Throwable {
		waitForElement(By.className("menu-navegacao-conteudo-145"));
		driver.findElement(By.className("menu-navegacao-conteudo-145")).click();
		System.out.println("Search link was clicked");
	}

	@Then("^See Search page$")
	public void see_search_page() throws Throwable {
		waitForElement(By.xpath("//h1[contains(text(), 'Pesquisa na Universidade do Porto')]"));
		System.out.println("Search page was opened");
	}

	// ---------------------------------------------------------

	@Given("^Open Sigarra Search page$")
	public void open_Sigarra_Search_page() throws Throwable {
		open_Sigarra_page();
		click_on_Search();
		see_search_page();
	}

	@When("^Search \"([^\"]*)\"$")
	public void search_query(String query) throws Throwable {
		waitForElement(By.name("pv_pesq"));
		driver.findElement(By.name("pv_pesq")).sendKeys(query);
		driver.findElement(By.id("searchsubmit")).click();
		System.out.println("Search for " + query);
	}

	@And("^Click on first result$")
	public void click_on_first_result() throws Throwable {
		waitForElement(By.xpath(
				"//div[@id='GoogleSearch']/div/div[1]/div/div/div/div/div[5]/div[2]/div[1]/div/div[1]/div[1]/div[1]/div/a"));
		driver.findElement(By.xpath(
				"//div[@id='GoogleSearch']/div/div[1]/div/div/div/div/div[5]/div[2]/div[1]/div/div[1]/div[1]/div[1]/div/a"))
				.click();
		System.out.println("First result link was clicked");
	}

	@Then("^See Sigarra FEUP page$")
	public void see_Sigarra_FEUP_page() throws Throwable {
		switchToOpenedWindow();
		waitForElement(By.xpath("//h1[contains(text(), 'Faculdade de Engenharia da Universidade do Porto')]"));
		System.out.println("FEUP page was opened");
	}

	// ---------------------------------------------------------

	@Given("^Open Sigarra FEUP page$")
	public void open_Sigarra_FEUP_page() throws Throwable {
		open_Sigarra_Search_page();
		search_query("FEUP");
		click_on_first_result();
		see_Sigarra_FEUP_page();
	}

	@When("^Click on Map on \"([^\"]*)\"$")
	public void click_on_Map_building(String building) throws Throwable {
		waitForElement(By.xpath("//area[contains(@title, '" + building + "')]"));
		elementJsClick(By.xpath("//area[contains(@title, '" + building + "')]"));
		System.out.println("Building " + building + " was opened");
	}

	@Then("^See \"([^\"]*)\" page$")
	public void see_page(String buildingName) throws Throwable {
		waitForElement(By.xpath("//h1[contains(text(), '" + buildingName + "')]"));
		System.out.println("Map page was opened");
	}

	// ---------------------------------------------------------

	@After()
	public void closeBrowser() {
		freezeStepSeconds(3);
		driver.quit();
		System.out.println("Browser was closed");
	}

	private void freezeStepSeconds(long seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			// do nothing
		}
	}

	private void waitForElement(By locator) {
		WebDriverWait driverWait = new WebDriverWait(driver, 20L);
		driverWait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	private void elementJsClick(By locator) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", driver.findElement(locator));
	}

	private void switchToOpenedWindow() {
		freezeStepSeconds(5);
		Set<String> handles = driver.getWindowHandles();
		String currentHandle = driver.getWindowHandle();
		for (String handle : handles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
	}
}
